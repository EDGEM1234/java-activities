module JavaQuest {
}