package JavaQuiz;
import java.io.*;
import java.util.*;
import java.util.Scanner;
public class JavaQuiz {	     

	static Scanner cin = new Scanner(System.in);

	    public static void main(String[] args){

	           int correct = 0;

	           int incorrect=0;

	          int questions = 15;

	          System.out.println("Welcome to the Multiple Choice Quiz! \n");



	           String[][] Ques_Ans = {
	        		   
     {"The ability to define more than one function with the same name ","\n a. Polymorphism \n b. Inheritance \n c. Encapsulation \n d. Abstraction\n","a"},
	      
     {"Which one pertains to runtime polymorphism? ","\n a. Method Overloading \n b. Method Overriding \n c. Methods \n d. Array\n","b"},
     
	 {"What supports Encapsulation? ","\n a. Methods \n b. Objects \n c. Classes \n d. Inheritance","c"},
	 
	 {"Which ones do you combine into a class in order to achieve Encapsulation? ","\n a. Methods and Attributes \n b. Methods and Objects\n c. Objects and Attributes \n d. None of the Above\n","a"},
	 
	 {"Another term for encapsulation ","\n a.Data Hiding \n b. Data Protection \n c. Collections \n d. Data Encapsulations\n","a"},

	 {"What do you use in order to implement Encapsulation? ","\n a. public \n b. private \n c. float \n d. double\n","b"},
	 
	 {"The type of inheritance that java has ","\n a. Single Inheritance \n b. Double Inheritance \n c. Multi Inheritance \n d. None\n","a"},
	 
	 {"It is a disadvantage when using inheritance ","\n a. Use of superclasses \n b. Enhancement to a based class are automatically applied to derived classes \n c. Consistency among similar classes \n d. Classes that have shared codes only need to be written once\n","b"},
	 
	 {"Which of the following is true about exceptions? ","\n a. They are thrown at runtime during the execution of a program using java \n b. Undefined Variables are examples of exceptions \n c. None of these are correct \n d. All of the above\n","a"},

	 {"Used to inherit a class ","\n a. extends \n b. extend \n c. double \n d. private\n","a"},

	 {"Class members that are declared protected are under which category of subclasses? ","\n a. public member \n b. private member \n c. class member \n d. None of the Above\n","b"},
	 
	 {"How do you extend Bclass to Aclass? ","\n a.Aclass Extends Bclass  \n b. Bclass extends Bclass \n c. Both  \n d. None\n","d"},
	 
	 {"How can you implement multiple inheritance in java? ","\n a. Interfaces \n b. Private methods \n c. Both \n d.  None\n","a"},
	 
	 {"Which does not belong to the group? ","\n a. Single Inheritance \n b. Double Inheritance \n c. Hierarchical Inheritance \n d. None of the above\n","b"},

	 {"Used to find the length of a string in JAVA","\n a. length() \n b. getlength() \n c. len \n d. getsize()\n","a"}};



	          String[] user_ans = new String[(int) questions];

	          int i=0;

	           

	          do {

	              System.out.print("" + (i+1) + ". " + Ques_Ans[i][0] + "   "+Ques_Ans[i][1]);

	              user_ans[i] = String.valueOf(cin.next().charAt(0));

	              

	                isValid(user_ans);

	              

	              

	              if(Ques_Ans[i][2].equals(user_ans[i])) {

	                  System.out.println("\n Correct!");

	                   correct++; 

	                  

	              }

	              else

	              {

	                  System.out.println("\n Incorrect. The correct answer is "+Ques_Ans[i][2]);

	                  incorrect++;

	              }



	              System.out.print("\n");

	              i++;

	         }while(i<questions);                      



	         System.out.println("\n Number of correct answers: "+ correct);

	         System.out.println("\n Number of incorrect answers: "+ incorrect);

	         System.exit(0);

	    }

		private static void isValid(String[] user_ans) {
			// TODO Auto-generated method stub
			
		}



	}
